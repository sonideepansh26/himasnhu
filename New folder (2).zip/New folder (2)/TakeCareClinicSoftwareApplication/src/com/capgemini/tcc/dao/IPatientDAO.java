package com.capgemini.tcc.dao;
import com.capgemini.tcc.bean.Patientbean;
import com.capgemini.tcc.exception.PatientException;
public interface IPatientDAO {
	public String addPatientDetails(Patientbean patientbean) throws PatientException;
}





