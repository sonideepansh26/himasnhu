package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.Patientbean;
import com.capgemini.tcc.exception.PatientException;


public interface IPatientService {
	public String addPatientDetails(Patientbean patientbean) throws PatientException;
}
