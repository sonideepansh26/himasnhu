package com.capgemini.tcc.test;  

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.tcc.bean.Patientbean;
import com.capgemini.tcc.dao.PatientDaoImpl;
import com.capgemini.tcc.exception.PatientException;


public class PatientDaoTest {

    static PatientDaoImpl dao;
    static Patientbean patientbean;

    @BeforeClass
    public static void initialize() {
        dao = new PatientDaoImpl();
        patientbean = new Patientbean();
    }

    @Test
    public void testAddPatientDetails() throws PatientException {

        assertNotNull(dao.addPatientDetails(patientbean));
    }
    
    /************************************
     * Test case for addPatientDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddPatientDetails1() throws PatientException {
        assertEquals(1001, dao.addPatientDetails(patientbean));
    }

    /************************************
     * Test case for addPatientDetails()
     * 
     ************************************/

    @Test
    public void testAddPatientDetails2() throws PatientException {
        
    	patientbean.setName("com");
    	patientbean.setPhoneNumber("9000342237");
    	patientbean.setAge("22");
    	patientbean.setDescription("apple");
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addPatientDetails(patientbean)) > 1000);

    }
}